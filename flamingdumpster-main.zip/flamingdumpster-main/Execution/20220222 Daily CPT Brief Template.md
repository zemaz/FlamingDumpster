# Daily CPT Brief < Date >


### Time-hack (observation)
### Roll-call
#### < list Operators and assignments here >
### Review crew ORM scores on C2 Chat
### Intel
#### FFIR
#### RFI
### Outline target end-state for shift
### Review tactical objectives/tasks/MOPs w/ assignment to reach end-state
### Highlight changes to Comm Contracts / Ops Procedures
